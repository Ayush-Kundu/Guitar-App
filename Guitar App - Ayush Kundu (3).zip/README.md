
  # Guitar App - Ayush Kundu

  This is a code bundle for Guitar App - Ayush Kundu. The original project is available at https://www.figma.com/design/L8bb88XEzef7anZhbqTnBv/Guitar-App---Ayush-Kundu.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  